# 🔧 WS63 激光打标机 — 开发调试指南

> 📌 本文档帮助你**从程序到实物**，逐步、有序地完成系统调试。
> 按照阶段顺序执行，每个阶段都有明确的通过标准。

---

## 📋 目录

- [一、系统模块关系](#一系统模块关系)
- [二、接收板函数手册](#二接收板函数手册)
- [三、发射板函数手册](#三发射板函数手册)
- [四、数据流全链路](#四数据流全链路)
- [五、10 阶段调试计划](#五10-阶段调试计划)
- [六、常见问题排查](#六常见问题排查)

---

## 一、系统模块关系

### 整体架构

```mermaid
graph TB
    subgraph "📡 发射板 Transmitter"
        T_MAIN["🚀 main.c"] --> T_UART["📟 uart_handler.c"]
        T_MAIN --> T_SLE["📶 sle_client.c"]
        T_UART --> T_PARSE["📝 gcode_parser.c"]
        T_PARSE --> T_PROC["⚙️ gcode_processor.c"]
        T_PROC --> T_SLE
    end

    subgraph "🎯 接收板 Receiver"
        R_MAIN["🚀 main.c"] --> R_SLE["📶 sle_server.c"]
        R_MAIN --> R_QUEUE["📦 cmd_queue.c"]
        R_MAIN --> R_INTERP["🎯 interpolator.c"]
        R_MAIN --> R_DAC["🔌 dac8562.c"]
        R_MAIN --> R_LASER["💡 laser_ctrl.c"]
        R_MAIN --> R_SAFE["🛡️ safety_monitor.c"]

        R_SLE -->|"写入"| R_QUEUE
        R_QUEUE -->|"取出"| R_INTERP
        R_INTERP --> R_DAC
        R_INTERP --> R_LASER
        R_SAFE -.->|"超时关激光"| R_LASER
    end

    T_SLE ==>|"motion_cmd_t<br/>20 bytes"| R_SLE
    R_SLE -.->|"status_pkt_t<br/>8 bytes"| T_SLE
```

### 模块依赖速览

```
接收板:  main → dac8562 (独立)
                laser_ctrl (独立)
                cmd_queue (独立)
                sle_server → cmd_queue, safety_monitor, crc16
                interpolator → cmd_queue, dac8562, laser_ctrl, safety_monitor
                safety_monitor → laser_ctrl, cmd_queue

发射板:  main → uart_handler, sle_client, gcode_processor
                uart_handler → gcode_parser → gcode_processor → sle_client
```

> [!TIP]
> 依赖关系越少的模块越应该**先调试**。`dac8562` 和 `laser_ctrl` 完全独立，是最佳起点。

---

## 二、接收板函数手册

### 🚀 `main.c` — 系统入口

```
receiver_entry()          系统启动入口 (app_run 注册)
  ├── dac8562_init()       初始化 DAC SPI
  ├── laser_ctrl_init()    初始化激光 PWM
  ├── interpolator_init()  坐标归零
  ├── safety_monitor_init()确保激光默认关
  ├── cmd_queue_init()     创建 mutex + semaphore
  │
  ├── 创建任务 → task_interpolator_entry  优先级 2
  ├── 创建任务 → task_safety_entry        优先级 2
  └── 创建任务 → sle_init_task            优先级 3
                   └── sle_laser_server_init()
```

---

### 🔌 `dac8562.c` — DAC SPI 驱动

> 控制 DAC8562 双通道 16-bit DAC，驱动振镜 X/Y 轴

| 函数 | 作用 | 备注 |
|------|------|------|
| `dac8562_init()` | SPI Mode1 初始化 + DAC 上电序列 | ⬅️ 第一个调试 |
| `dac8562_write_channel(cmd, value)` | 发送 3 字节 `[cmd][高][低]` | MSB first |
| `dac8562_write_xy(x, y)` | 依次写 DAC-A(X) 和 DAC-B(Y) | 被插补引擎高频调用 |

> [!IMPORTANT]
> 字节序已经修正——直接 `{cmd, value>>8, value&0xFF}` 发送，**不要**参考 Arduino 原始库的反转写法。

---

### 📦 `cmd_queue.c` — 线程安全命令队列

> 32 条深度的环形缓冲区，生产者-消费者模式

| 函数 | 谁调用 | 阻塞？ | 说明 |
|------|--------|:------:|------|
| `cmd_queue_init()` | main | — | 创建 mutex + semaphore |
| `cmd_queue_push(cmd)` | SLE Server | 否 | 满时返回 false |
| `cmd_queue_pop(cmd)` | 插补任务 | **是** | 信号量等待，有命令才返回 |
| `cmd_queue_free_count()` | SLE Server | 否 | 用于流控反馈 |
| `cmd_queue_flush()` | 安全任务 | 否 | 清空队列 + 耗尽信号量 |

---

### 🎯 `interpolator.c` — 插补引擎 (核心)

> 从 Arduino `performMove()` 移植，使用 `osal_udelay` 忙等

| 函数 | 说明 |
|------|------|
| `perform_move(x, y, feed)` | ⭐ 核心插补函数 |
| `interpolator_get_x/y()` | 获取当前坐标 |
| `interpolator_set_origin()` | 坐标归零 (G92) |
| `task_interpolator_entry()` | 任务主循环：阻塞取命令 → 执行 |

**`perform_move` 执行流程:**

```
1. 计算 distance = sqrt(dx² + dy²)
2. 计算 steps = distance / 0.1mm
3. 计算 step_time_us = 总时间 / steps
           │
           ▼
4. osal_kthread_lock()          ← 锁住任务调度
           │
    ┌──────▼──────┐
    │  循环 1→steps │
    │  更新 X, Y    │◄──── dac8562_write_xy()
    │  忙等延时     │◄──── osal_udelay(step_time_us)
    │  每200步解锁   │◄──── unlock → lock (让 SLE 任务呼吸)
    └──────┬──────┘
           │
5. osal_kthread_unlock()        ← 恢复调度
6. 修正终点坐标 (消除浮点累积误差)
```

---

### 💡 `laser_ctrl.c` — 激光 PWM

| 函数 | 说明 |
|------|------|
| `laser_ctrl_init()` | 配置 PWM 引脚 |
| `laser_set_power(0~1000)` | 设置占空比: `power/1000 × 100%` |
| `laser_enable(true/false)` | 开/关 PWM 输出 |

---

### 🛡️ `safety_monitor.c` — 安全看门狗

| 函数 | 谁调用 | 说明 |
|------|--------|------|
| `safety_update_last_sle_time()` | SLE Server | 收到包时喂狗 |
| `safety_set_sle_connected(bool)` | SLE Server | 连接/断连时更新 |
| `task_safety_entry()` | RTOS | 每 10ms 检查: 连接后 >150ms 无数据 → 关激光 |

---

### 📶 `sle_server.c` — SLE 服务端

**关键回调链:**

```
SLE 协议栈
  ├── sle_enable_cbk
  │     └── sle_server_enable_cbk()     注册服务 + 广播 "LaserRX"
  ├── sle_connect_state_changed_cbk
  │     ├── CONNECTED  → safety_set_sle_connected(true)
  │     └── DISCONNECTED → laser_enable(false) + 重启广播
  └── ssaps_write_request_cbk           ⬅️ 数据入口!
        ├── 校验长度 == sizeof(motion_cmd_t)
        ├── motion_cmd_check_crc()
        ├── safety_update_last_sle_time()
        ├── cmd_queue_push(&cmd)         ← 命令入队
        └── sle_laser_server_send_status()  ← ACK 返回
```

---

## 三、发射板函数手册

### 📝 `gcode_parser.c` — 纯 C 解析器

| 函数 | 说明 | 示例 |
|------|------|------|
| `gcode_add_char(gc, c)` | 逐字符添加 (自动转大写) | `'g'` → `'G'` |
| `gcode_parse(gc)` | 去注释 + 去空白 | `"G1 X10 ; comment"` → `"G1 X10"` |
| `gcode_has_word(gc, 'X')` | 检查有无某字母 | `true` |
| `gcode_get_value(gc, 'X')` | 提取字母后的数值 | `10.0` |

---

### ⚙️ `gcode_processor.c` — G-Code → motion_cmd_t

**处理优先级:** `F(速度)` → `S(功率)` → `M(激光)` → `G(运动)`

| G-Code | 生成的 cmd | 说明 |
|--------|-----------|------|
| `G0 X10 Y20` | `CMD_G0_MOVE` | 快速移动 (G0_FEED_RATE) |
| `G1 X10 Y20 F5000` | `CMD_G1_MOVE` | 直线插补 (指定速度) |
| `M3 S500` | `CMD_LASER_ON` | 开启激光 (功率 500) |
| `M5` | `CMD_LASER_OFF` | 关闭激光 |
| `G92` | `CMD_SET_ORIGIN` | 设置当前为原点 |
| `$I` | 不发 SLE | 直接 UART 回复版本信息 |
| `?` | 不发 SLE | 直接 UART 回复状态 |

---

### 📶 `sle_client.c` — SLE 客户端

```
sle_laser_client_init()
  ├── 注册扫描/连接/SSAP回调
  └── enable_sle();
         │
         ▼
  sle_enable_cbk → 开始扫描
         │
         ▼ 扫到 "LaserRX"
  sle_sample_seek_result_cbk → sle_connect_remote_device()
         │
         ▼ 连接成功
  sle_connect_state_changed_cbk → ssapc_find_structure() 发现服务
         │
         ▼
  可以调用 sle_laser_client_send_cmd() 发送 motion_cmd_t
```

---

### 📟 `uart_handler.c` — UART + Grbl 兼容

```
task_uart_rx_entry() 主循环
  │
  ├── 逐字节读取 UART
  │     └── 遇到 '\n' → 拼成完整行
  │
  └── process_line(line)
        ├── line[0] == '?' → grbl_format_status() → UART 回复
        ├── line[0] == '$' → grbl_process_dollar() → UART 回复
        └── 其他 → gcode_process_line()
                    ├── 生成 motion_cmd_t[]
                    ├── 流控等待 (queue_free >= 4)
                    ├── sle_laser_client_send_cmd() 发送
                    └── uart_send_str("ok\r\n")
```

---

## 四、数据流全链路

```
   上位机                    发射板                          接收板
  LaserGRBL                 WS63-TX                        WS63-RX
     │                         │                              │
     │ "G1 X10 Y20 F5000\n"   │                              │
     │ ───────UART──────────►  │                              │
     │                         │                              │
     │                    uart_handler                        │
     │                    gcode_parser                        │
     │                    gcode_processor                     │
     │                         │                              │
     │                         │  motion_cmd_t (20B+CRC)      │
     │                         │ ──────SLE 星闪─────────────►  │
     │                         │                              │
     │                         │                         sle_server
     │                         │                         CRC校验 ✓
     │                         │                         cmd_queue_push
     │                         │                              │
     │                         │                         interpolator
     │                         │                         perform_move
     │                         │                              │
     │                         │                         dac8562_write_xy
     │                         │                         osal_udelay
     │                         │                              │
     │                         │                          🎯 振镜移动
     │                         │                          💡 激光打标
     │                         │                              │
     │                         │   status_pkt_t (8B)          │
     │                         │ ◄──────SLE──────────────────  │
     │                         │                              │
     │  "ok\r\n"               │                              │
     │ ◄────────UART────────── │                              │
```

---

## 五、10 阶段调试计划

> [!IMPORTANT]
> **核心原则: 从底层到顶层，从单板到双板，逐层验证。**
> 每个阶段都有「通过标准」，只有通过后才进入下一阶段。

---

### 阶段 1️⃣ — 环境验证 `1天`

> 📋 确认编译→烧录→运行链路正常

| ✅ 通过标准 |
|------------|
| LED 以 5 秒间隔正常闪烁 |

操作: 勾选 `MY_LED` → 编译 → 烧录 → 观察

---

### 阶段 2️⃣ — DAC SPI 驱动 `2-3天` 🔧接收板

> 📋 确认 SPI 能正确控制 DAC8562

**临时测试代码** (替换 `receiver/main.c` 的 `receiver_entry`):
```c
static void receiver_entry(void) {
    dac8562_init();
    while (1) {
        dac8562_write_channel(DAC_CMD_SETA_UPDATEA, 0);      // 0V
        osal_msleep(1000);
        dac8562_write_channel(DAC_CMD_SETA_UPDATEA, 32768);  // Vref/2
        osal_msleep(1000);
        dac8562_write_channel(DAC_CMD_SETA_UPDATEA, 65535);  // Vref
        osal_msleep(1000);
    }
}
```

| 步骤 | 操作 | ✅ 通过标准 |
|:----:|------|------------|
| 2.1 | 编译只含 `dac8562.c` 的最小代码 | 编译无错 |
| 2.2 | 写入 32768，万用表测 DAC-A | ~1.25V (Vref/2) |
| 2.3 | 写入 0 和 65535 | 0V 和 ~2.5V |
| 2.4 | 示波器看 CS / CLK / MOSI 波形 | SPI Mode1 时序正确 |
| 2.5 | `dac8562_write_xy()` 写两个通道 | A/B 独立变化 |

> [!WARNING]
> 如果输出不对，先检查: ① CS 引脚编号 ② SPI 总线编号 ③ CPOL/CPHA 设置

---

### 阶段 3️⃣ — 激光 PWM `1天` 🔧接收板

| 步骤 | 操作 | ✅ 通过标准 |
|:----:|------|------------|
| 3.1 | `laser_set_power(500)` + `laser_enable(true)` | 示波器: 50% 占空比 |
| 3.2 | 遍历 0 / 250 / 500 / 750 / 1000 | 占空比线性变化 |

---

### 阶段 4️⃣ — 插补引擎 `2-3天` 🔧接收板 ⭐关键

> 📋 验证 DAC + osal_udelay 联动实现平滑运动

**临时测试代码:**
```c
static void receiver_entry(void) {
    dac8562_init();
    interpolator_init();
    while (1) {
        perform_move(10, 0,  5000);   // →
        perform_move(10, 10, 5000);   // ↑
        perform_move(0,  10, 5000);   // ←
        perform_move(0,  0,  5000);   // ↓
        osal_msleep(500);             // 暂停
    }
}
```

| 步骤 | 操作 | ✅ 通过标准 |
|:----:|------|------------|
| 4.1 | `perform_move(10, 0, 5000)` | 万用表看 DAC-A 平滑变化 |
| 4.2 | 正方形路径循环 | 示波器看到重复波形 |
| 4.3 | GPIO toggle 测 `osal_udelay(20)` 实际间隔 | 误差 <5μs |
| 4.4 | 连接振镜，运行正方形 | 肉眼确认方形轨迹 |

---

### 阶段 5️⃣ — 命令队列 `1天` 🔧接收板

| 步骤 | 操作 | ✅ 通过标准 |
|:----:|------|------------|
| 5.1 | 生产者任务 push 10 条命令，消费者 pop 并打印 | 顺序正确 |
| 5.2 | push 超过 32 次 | 返回 false，系统不崩溃 |
| 5.3 | `cmd_queue_flush()` 后 pop | 阻塞不返回 |

---

### 阶段 6️⃣ — UART 通信 `1天` 🔧发射板

| 步骤 | 操作 | ✅ 通过标准 |
|:----:|------|------------|
| 6.1 | 串口助手发送 `hello\n` | 回复 `ok\r\n` |
| 6.2 | 发送 `$I\n` | 回复版本信息 |
| 6.3 | 发送 `?` | 回复 `<Idle\|MPos:...>` |
| 6.4 | 发送 `G1 X10 Y20 F5000\n` | 回复 `ok\r\n` |

---

### 阶段 7️⃣ — G-Code 解析 `1天` 🔧发射板

| 步骤 | 操作 | ✅ 通过标准 |
|:----:|------|------------|
| 7.1 | `printk` 输出 `gcode_process_line` 结果 | X=10 Y=20 F=5000 |
| 7.2 | 测试所有命令类型 | M3/M5/G0/G1/G90/G91/G92 正确 |
| 7.3 | `motion_cmd_set_crc` + `check_crc` | CRC 验证一致 |

---

### 阶段 8️⃣ — SLE 双板通信 `3-5天` 🔧双板 ⭐最复杂

> [!CAUTION]
> 建议先单独跑通官方 `sle_speed_server` + `sle_speed_client` 示例，确认 SLE 链路正常后再改造。

| 步骤 | 操作 | ✅ 通过标准 |
|:----:|------|------------|
| 8.1 | 跑官方 speed server/client 示例 | 两板能连接并收发 |
| 8.2 | 接收板广播 "LaserRX" | 手机/工具能扫到 |
| 8.3 | 发射板自动扫描连接 | 日志 "connected" |
| 8.4 | 发一条固定 `motion_cmd_t` | 接收板打印字段正确 + CRC✓ |
| 8.5 | 接收板回复 `status_pkt_t` | 发射板收到 `ack_seq` 正确 |
| 8.6 | 连续发 100 条命令 | 无丢包，流控正常 |

---

### 阶段 9️⃣ — 安全模块 `1天` 🔧接收板

| 步骤 | 操作 | ✅ 通过标准 |
|:----:|------|------------|
| 9.1 | SLE 连接中开激光 → 断开发射板 | 150ms 内激光自动关 |
| 9.2 | 上电检查 | 激光默认关闭 |

---

### 阶段 🔟 — 端到端联调 `2-3天` 🔧全系统

| 步骤 | 操作 | ✅ 通过标准 |
|:----:|------|------------|
| 10.1 | LaserGRBL 连接发射板 | 左下角 "Connected" |
| 10.2 | 发送 `?` | 界面显示 MPos 坐标 |
| 10.3 | 手动 `G0 X10 Y10` | 振镜移动 |
| 10.4 | 加载矩形图形 → 打标 | 激光画矩形 |
| 10.5 | 复杂图形 | 无卡顿、轨迹连续 |

---

## 六、常见问题排查

| 🔴 现象 | 🔍 可能原因 | 🔧 排查方法 |
|---------|------------|-------------|
| DAC 无输出 | SPI 配置错 / CS 引脚错 | 示波器看 CS/CLK/MOSI 波形 |
| 振镜抖动 | 忙等被中断打断 | 增大 `INTERP_UNLOCK_INTERVAL` (如 500) |
| SLE 扫不到 | 广播名不匹配 | `printk` 确认广播了 "LaserRX" |
| 上位机连不上 | 波特率错 / TX/RX 接反 | 用串口助手先测基本收发 |
| 打标变形 | `BEILV` 值不对 / XY 通道接反 | 先打正方形校准 |
| 激光不亮 | PWM 引脚未配置 / 安全模块关了 | 检查 `laser_is_enabled()` |
| 队列溢出 | 发送太快 / 流控没生效 | `printk` 看 `queue_free` 值 |
| CRC 校验失败 | 大小端问题 / 结构体对齐 | `printk` 打印收发两端的原始字节 |
