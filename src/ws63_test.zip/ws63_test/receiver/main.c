/**
 * @file main.c
 * @brief 接收板主入口 — 创建所有 RTOS 任务
 */
#include "app_init.h"
#include "soc_osal.h"
#include "common_def.h"
#include "config.h"

#include "dac8562.h"
#include "cmd_queue.h"
#include "interpolator.h"
#include "laser_ctrl.h"
#include "safety_monitor.h"
#include "sle_server.h"

/* 前向声明 */
static int sle_init_task(void *arg);

static void receiver_entry(void)
{
    osal_printk("========================================\r\n");
    osal_printk("  WS63 Laser Marker - Receiver Board\r\n");
    osal_printk("========================================\r\n");

    /* 1. 硬件初始化 */
    dac8562_init();
    laser_ctrl_init();
    interpolator_init();
    safety_monitor_init();
    cmd_queue_init();

    osal_printk("[receiver] hardware init OK\r\n");

    osal_task *task = NULL;

    /* 2. 创建插补引擎任务 (最高优先级) */
    osal_kthread_lock();
    task = osal_kthread_create(task_interpolator_entry, NULL, "interp", TASK_STACK_SIZE_DEFAULT);
    if (task != NULL) {
        osal_kthread_set_priority(task, TASK_PRIO_INTERPOLATOR);
    }

    /* 3. 创建安全监控任务 */
    task = osal_kthread_create(task_safety_entry, NULL, "safety", TASK_STACK_SIZE_DEFAULT);
    if (task != NULL) {
        osal_kthread_set_priority(task, TASK_PRIO_SAFETY);
    }

    /* 4. 创建 SLE 初始化任务 */
    task = osal_kthread_create(sle_init_task, NULL, "sle_init", TASK_STACK_SIZE_SLE);
    if (task != NULL) {
        osal_kthread_set_priority(task, TASK_PRIO_SLE);
    }
    osal_kthread_unlock();

    osal_printk("[receiver] all tasks created\r\n");
}

static int sle_init_task(void *arg)
{
    unused(arg);
    osal_msleep(500); /* 等待系统稳定 */
    sle_laser_server_init();
    return 0;
}

/* 系统启动入口 */
app_run(receiver_entry);
