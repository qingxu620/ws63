/**
 * @file interpolator.c
 * @brief 插补引擎实现 — 从 Arduino performMove() 移植
 *        使用 osal_udelay() 忙等实现微秒级精确延时
 *        使用 osal_kthread_lock/unlock 防止任务切换
 */
#include "interpolator.h"
#include "config.h"
#include "protocol.h"
#include "dac8562.h"
#include "cmd_queue.h"
#include "laser_ctrl.h"
#include "safety_monitor.h"
#include "soc_osal.h"
#include <math.h>

/* ================= 全局状态 ================= */
static double g_current_x = 0.0;
static double g_current_y = 0.0;

/* ================= 坐标转换 ================= */
static inline uint16_t mm_to_dac(double mm)
{
    double val = mm * BEILV;
    if (val < 0)
        val = 0;
    if (val > DAC_MAX)
        val = DAC_MAX;
    return (uint16_t)val;
}

/* ================= 核心插补函数 ================= */
void perform_move(double target_x, double target_y, double feed_rate_mm_min)
{
    double dx = target_x - g_current_x;
    double dy = target_y - g_current_y;
    double distance = sqrt(dx * dx + dy * dy);

    /* 距离太小，直接跳到目标点 */
    if (distance < STEP_NUM) {
        g_current_x = target_x;
        g_current_y = target_y;
        dac8562_write_xy(mm_to_dac(g_current_x), mm_to_dac(g_current_y));
        return;
    }

    /* 速度转换 mm/min → mm/sec */
    double feed_sec = feed_rate_mm_min / 60.0;
    if (feed_sec < 0.1)
        feed_sec = 0.1;

    /* 计算步数和每步增量 */
    int steps = (int)(distance / STEP_NUM);
    if (steps < 1)
        steps = 1;

    double step_dx = dx / steps;
    double step_dy = dy / steps;

    /* 计算每步延时 (微秒) */
    double total_time_sec = distance / feed_sec;
    double step_time_us = (total_time_sec * 1000000.0) / steps;
    if (step_time_us < 1)
        step_time_us = 1;

    unsigned int delay_us = (unsigned int)step_time_us;

    /*
     * 锁住任务调度，防止被其他任务抢占导致运动抖动
     * 注意: osal_kthread_lock() 只锁任务切换，不屏蔽硬件中断
     */
    osal_kthread_lock();

    for (int i = 1; i <= steps; i++) {
        g_current_x += step_dx;
        g_current_y += step_dy;

        /* 更新 DAC 输出 */
        dac8562_write_xy(mm_to_dac(g_current_x), mm_to_dac(g_current_y));

        /* 微秒级忙等延时 — 与 Arduino delayMicroseconds() 等效 */
        osal_udelay(delay_us);

        /*
         * 每 INTERP_UNLOCK_INTERVAL 步释放一次调度
         * 让 SLE 接收任务有机会将新命令入队
         */
        if (i % INTERP_UNLOCK_INTERVAL == 0) {
            osal_kthread_unlock();
            osal_kthread_lock();
        }
    }

    osal_kthread_unlock();

    /* 修正终点坐标 (消除浮点累积误差) */
    g_current_x = target_x;
    g_current_y = target_y;
    dac8562_write_xy(mm_to_dac(g_current_x), mm_to_dac(g_current_y));
}

/* ================= 状态接口 ================= */

double interpolator_get_x(void)
{
    return g_current_x;
}
double interpolator_get_y(void)
{
    return g_current_y;
}

void interpolator_set_origin(void)
{
    g_current_x = 0.0;
    g_current_y = 0.0;
    dac8562_write_xy(0, 0);
}

void interpolator_init(void)
{
    g_current_x = 0.0;
    g_current_y = 0.0;
}

/* ================= 插补任务入口 ================= */
int task_interpolator_entry(void *arg)
{
    (void)arg;
    motion_cmd_t cmd;

    osal_printk("[interpolator] task started\r\n");

    while (1) {
        /* 阻塞等待命令 */
        if (!cmd_queue_pop(&cmd)) {
            continue;
        }

        /* 处理命令 */
        switch (cmd.cmd) {
            case CMD_G0_MOVE:
                /* G0 快速移动 — 使用最高速度 */
                perform_move(cmd.target_x, cmd.target_y, G0_FEED_RATE);
                break;

            case CMD_G1_MOVE:
                /* G1 直线插补 — 使用指定进给速度 */
                perform_move(cmd.target_x, cmd.target_y, cmd.feed_rate);
                break;

            case CMD_LASER_ON:
                laser_set_power(cmd.laser_pwr);
                laser_enable(true);
                break;

            case CMD_LASER_OFF:
                laser_enable(false);
                break;

            case CMD_SET_ORIGIN:
                interpolator_set_origin();
                break;

            default:
                break;
        }

        /* 更新安全看门狗 */
        safety_update_last_cmd_time();
    }

    return 0;
}
