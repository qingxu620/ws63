/**
 * @file safety_monitor.c
 * @brief 激光安全监控实现
 *        监控 SLE 连接状态，超时自动关闭激光
 */
#include "safety_monitor.h"
#include "config.h"
#include "laser_ctrl.h"
#include "cmd_queue.h"
#include "soc_osal.h"
#include "systick.h"

static volatile uint64_t g_last_sle_time = 0;
static volatile uint64_t g_last_cmd_time = 0;
static volatile bool g_sle_connected = false;

void safety_update_last_sle_time(void)
{
    g_last_sle_time = uapi_systick_get_ms();
}

void safety_update_last_cmd_time(void)
{
    g_last_cmd_time = uapi_systick_get_ms();
}

void safety_set_sle_connected(bool connected)
{
    g_sle_connected = connected;
    if (connected) {
        safety_update_last_sle_time();
    }
}

int task_safety_entry(void *arg)
{
    (void)arg;

    osal_printk("[safety] monitor task started\r\n");

    while (1) {
        uint64_t now = uapi_systick_get_ms();

        /* 检查 SLE 连接超时 */
        if (g_sle_connected && (now - g_last_sle_time > SAFETY_SLE_TIMEOUT_MS)) {
            osal_printk("[safety] SLE timeout! Laser OFF\r\n");
            laser_enable(false);
            laser_set_power(0);
            cmd_queue_flush();
        }

        osal_msleep(SAFETY_CHECK_INTERVAL_MS);
    }

    return 0;
}

void safety_monitor_init(void)
{
    /* 确保激光默认关闭 */
    laser_enable(false);
    laser_set_power(0);
    g_sle_connected = false;
}
