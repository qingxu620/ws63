/**
 * @file config.h
 * @brief 激光打标机系统全局配置
 */
#ifndef LASER_CONFIG_H
#define LASER_CONFIG_H

/* ================= 振镜/坐标配置 ================= */
#define BEILV 100     /* 脉冲当量: 1mm 对应的 DAC 数值 */
#define DAC_MAX 65535 /* DAC 最大值 (16-bit) */
#define STEP_NUM 0.1  /* 插补最小距离 (mm) */

/* ================= 速度配置 ================= */
#define DEFAULT_FEED_RATE 10000.0 /* 默认进给速度 mm/min */
#define G0_FEED_RATE 100000.0     /* G0 空走速度 mm/min */
#define LASER_S_MAX 1000.0        /* 激光功率最大值 */

/* ================= 通信配置 ================= */
#define UART_BAUD_RATE 115200
#define CMD_QUEUE_SIZE 32 /* 命令队列深度 */

/* ================= SLE 配置 ================= */
#define SLE_LASER_SERVER_NAME "LaserRX"
#define SLE_LASER_CLIENT_NAME "LaserTX"

/* ================= 安全配置 ================= */
#define SAFETY_SLE_TIMEOUT_MS 150   /* SLE 无数据包超时 (ms) */
#define SAFETY_CHECK_INTERVAL_MS 10 /* 安全检查周期 (ms) */
#define ACTIVITY_TIMEOUT_MS 200     /* 命令活动超时 → Idle 判定 (ms) */

/* ===========================================================================
 *  硬件引脚配置  —— 基于 WS63 引脚复用表
 *
 *  接收板 (Receiver):
 *  ┌──────────┬────────┬──────┬──────────┬──────────────────────┐
 *  │ 功能     │ GPIO   │ 引脚 │ PIN_MODE │ 复用功能             │
 *  ├──────────┼────────┼──────┼──────────┼──────────────────────┤
 *  │ SPI CLK  │ GPIO7  │ 31   │ MODE_3   │ SPI0_SCK             │
 *  │ SPI MOSI │ GPIO9  │ 33   │ MODE_3   │ SPI0_OUT             │
 *  │ SPI CS   │ GPIO10 │ 34   │ MODE_0   │ GPIO (手动控制)       │
 *  │ 激光 PWM │ GPIO2  │ 24   │ MODE_1   │ PWM2                 │
 *  └──────────┴────────┴──────┴──────────┴──────────────────────┘
 *
 *  发射板 (Transmitter):
 *  ┌──────────┬────────┬──────┬──────────┬──────────────────────┐
 *  │ 功能     │ GPIO   │ 引脚 │ PIN_MODE │ 复用功能             │
 *  ├──────────┼────────┼──────┼──────────┼──────────────────────┤
 *  │ UART TX  │ GPIO15 │ 9    │ MODE_1   │ UART1_TXD            │
 *  │ UART RX  │ GPIO16 │ 10   │ MODE_1   │ UART1_RXD            │
 *  └──────────┴────────┴──────┴──────────┴──────────────────────┘
 * =========================================================================== */

/* --- 接收板: SPI0 (DAC8562) --- */
#define DAC_SPI_BUS 0      /* SPI 总线编号 */
#define DAC_SPI_CLK_PIN 7  /* GPIO7  — Pin 31 — SPI0_SCK  */
#define DAC_SPI_MOSI_PIN 9 /* GPIO9  — Pin 33 — SPI0_OUT  */
#define DAC_CS_PIN 10      /* GPIO10 — Pin 34 — 手动 GPIO */
#define DAC_SPI_PIN_MODE 3 /* PIN_MODE_3 = 复用信号3 (SPI0) */

/* --- 接收板: PWM (激光控制) --- */
#define LASER_PWM_CHANNEL 2  /* PWM2 通道 */
#define LASER_PWM_PIN 2      /* GPIO2  — Pin 24 — PWM2     */
#define LASER_PWM_PIN_MODE 1 /* PIN_MODE_1 = 复用信号1 (PWM) */

/* --- 发射板: UART1 (上位机) --- */
#define LASER_UART_BUS 1      /* UART1 */
#define LASER_UART_TX_PIN 15  /* GPIO15 — Pin 9  — UART1_TXD */
#define LASER_UART_RX_PIN 16  /* GPIO16 — Pin 10 — UART1_RXD */
#define LASER_UART_PIN_MODE 1 /* PIN_MODE_1 = 复用信号1 (UART1) */

/* ================= 任务配置 ================= */
#define TASK_STACK_SIZE_DEFAULT 0x1000
#define TASK_STACK_SIZE_SLE 0x2000
#define TASK_PRIO_INTERPOLATOR 2 /* OSAL_TASK_PRIORITY_ABOVE_HIGH */
#define TASK_PRIO_SAFETY 2
#define TASK_PRIO_SLE 3 /* OSAL_TASK_PRIORITY_HIGH */
#define TASK_PRIO_UART 3
#define TASK_PRIO_DEFAULT 24

/* ================= 流控配置 ================= */
#define FLOW_CTRL_PAUSE_THRESHOLD 4   /* queue_free < 4 暂停发送 */
#define FLOW_CTRL_RESUME_THRESHOLD 16 /* queue_free > 16 恢复发送 */
#define CMD_RETRY_MAX 3               /* 最大重传次数 */
#define CMD_ACK_TIMEOUT_MS 500        /* ACK 超时时间 */

/* ================= 插补引擎配置 ================= */
#define INTERP_UNLOCK_INTERVAL 200 /* 每 N 步解锁一次调度 */

#endif /* LASER_CONFIG_H */
