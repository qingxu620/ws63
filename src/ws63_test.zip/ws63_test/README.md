# WS63 星闪激光打标机

基于 WS63 芯片的双板星闪 (SLE) 激光打标系统，从 Arduino 项目移植。

## 系统架构

```
上位机 (LaserGRBL) ──UART──> 发射板 (WS63) ──SLE──> 接收板 (WS63) ──> 振镜+激光
```

- **发射板**: 接收 G-Code → 解析 → 打包为 `motion_cmd_t` → 通过 SLE 发送
- **接收板**: 接收命令 → 本地插补 → 驱动 DAC8562 (振镜) + PWM (激光)

## 目录结构

```
ws63_test/
├── common/              # 共享模块
│   ├── config.h         # 全局配置
│   ├── protocol.h       # 通信协议定义
│   ├── crc16.h/c        # CRC16 校验
├── receiver/            # 接收板固件
│   ├── main.c           # 入口 + 任务创建
│   ├── dac8562.h/c      # DAC8562 SPI 驱动
│   ├── cmd_queue.h/c    # 线程安全命令队列
│   ├── interpolator.h/c # 插补引擎 (核心)
│   ├── laser_ctrl.h/c   # 激光 PWM 控制
│   ├── safety_monitor.h/c # 安全看门狗
│   ├── sle_server.h/c   # SLE Server
│   └── CMakeLists.txt
├── transmitter/         # 发射板固件
│   ├── main.c           # 入口 + 任务创建
│   ├── gcode_parser.h/c # 纯 C G-Code 解析器
│   ├── gcode_processor.h/c # G-Code → motion_cmd_t
│   ├── sle_client.h/c   # SLE Client
│   ├── uart_handler.h/c # UART + Grbl 兼容
│   └── CMakeLists.txt
├── CMakeLists.txt       # 顶层构建
├── Kconfig              # 配置菜单
└── README.md
```

## 编译

在 Kconfig 中选择编译目标：
- `CONFIG_LASER_MARKER_RECEIVER=y` — 编译接收板固件
- `CONFIG_LASER_MARKER_TRANSMITTER=y` — 编译发射板固件

## 硬件连接

### 接收板
| 功能 | 引脚 | 说明 |
|------|------|------|
| DAC8562 CS | GPIO 2 | SPI 片选 |
| DAC8562 CLK/MOSI | SPI0 | 硬件 SPI |
| 激光 PWM | PWM0 | 1kHz PWM |

### 发射板
| 功能 | 引脚 | 说明 |
|------|------|------|
| UART TX/RX | UART0 | 连接上位机, 115200 baud |

> ⚠️ 引脚编号请根据实际硬件修改 `common/config.h`
