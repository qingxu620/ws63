# 📡 发射板 (Transmitter) 调试落实文档

## 整体数据流概览

```
LaserGRBL (PC)
    │ USB转串口 (115200 8N1)
    ▼
┌─── UART1 硬件 ──────────────┐
│  GPIO15 (TX) ← PC TX       │  阶段①  物理层
│  GPIO16 (RX) → PC RX       │
└─────────────────────────────┘
    │ 逐字节中断/轮询
    ▼
┌─── uart_handler.c ──────────┐
│  task_uart_rx_entry()       │  阶段②  字节→行
│  拼接字符 → 检测 \r\n       │
│  输出: char line[]          │
└─────────────────────────────┘
    │ process_line(line, len)
    ▼
┌─── 命令分流 ────────────────┐
│  '?' → grbl_format_status() │  阶段③  协议路由
│  '$' → grbl_process_dollar()│
│  其他 → gcode_process_line()│
└─────────────────────────────┘
    │ G-Code 文本行
    ▼
┌─── gcode_parser.c ──────────┐
│  gcode_init()               │  阶段④  文本→结构
│  gcode_add_char() (转大写)  │
│  gcode_parse() (去注释/trim)│
│  输出: gcode_line_t         │
└─────────────────────────────┘
    │ gcode_has_word() / gcode_get_value()
    ▼
┌─── gcode_processor.c ───────┐
│  提取 F/S/M/G 参数          │  阶段⑤  结构→命令包
│  生成 motion_cmd_t[]        │
│  填充 CRC16                 │
│  更新 g_line_counter        │
│  输出: motion_cmd_t cmds[4] │
└─────────────────────────────┘
    │ sle_laser_client_send_cmd(&cmd)
    ▼
┌─── sle_client.c ────────────┐
│  流控等待 (queue_free)      │  阶段⑥  SLE 无线发射
│  ssapc_write_req()          │
│  → 星闪射频 → 接收板        │
└─────────────────────────────┘
```

---

## 阶段① 物理层 — UART 硬件初始化

### 涉及文件
- [config.h](file:///root/fbb_ws63/src/ws63_test/common/config.h#L65-L69)
- [uart_handler.c](file:///root/fbb_ws63/src/ws63_test/transmitter/uart_handler.c#L123-L154) → `uart_handler_init()`

### 数据格式
```
PC (LaserGRBL) ←→ WS63 UART1
    协议: 115200 baud, 8 data bits, 1 stop bit, no parity
    方向: PC TX → WS63 GPIO16 (RX)
          PC RX ← WS63 GPIO15 (TX)
```

### 初始化流程
```c
// 1. 引脚复用设置
uapi_pin_set_ie(LASER_UART_RX_PIN, PIN_IE_1);     // RX 输入使能
uapi_pin_set_mode(GPIO15, PIN_MODE_1);              // → UART1_TXD
uapi_pin_set_mode(GPIO16, PIN_MODE_1);              // → UART1_RXD

// 2. UART 参数
uart_attr_t attr = { .baud_rate=115200, .data_bits=8, .stop_bits=1, .parity=NONE }
uart_pin_config_t pins = { .tx_pin=15, .rx_pin=16, .cts=NONE, .rts=NONE }

// 3. 初始化
uapi_uart_init(UART_BUS_1, &pins, &attr, NULL, NULL);
```

### 🔍 调试检查点
```c
// uart_handler.c:149 已有打印
"[uart] init OK, bus=1, TX=GPIO15, RX=GPIO16, baud=115200"

// 如果失败会打印
"[uart] init failed: 0x%x"
```

### 🛠️ 调试方法
1. **最基础测试**: 用万用表量 GPIO15 空闲时是否为高电平 (UART 空闲态)
2. **回环测试**: 短接 GPIO15 和 GPIO16，发什么收什么
3. **串口工具验证**: 先不用 LaserGRBL，用 PuTTY/minicom 手动发 `$I\n`，看是否收到 `[VER:1.1f.WS63:]`

---

## 阶段② 字节拼接成行 — UART 接收任务

### 涉及文件
- [uart_handler.c](file:///root/fbb_ws63/src/ws63_test/transmitter/uart_handler.c#L86-L121) → `task_uart_rx_entry()`

### 数据变换
```
输入: 逐字节 uint8_t (来自 UART 硬件 FIFO)
输出: 完整文本行 char g_rx_line[128]  (不含 \r\n)
```

### 处理逻辑
```c
while (1) {
    int32_t ret = uapi_uart_read(LASER_UART_BUS, &ch, 1, 0);  // 读 1 字节
    if (ret <= 0) { osal_msleep(1); continue; }                // 无数据则等 1ms

    if (ch == '\n' || ch == '\r') {
        if (g_rx_pos > 0) {
            g_rx_line[g_rx_pos] = '\0';
            process_line(g_rx_line, g_rx_pos);   // → 进入阶段③
            g_rx_pos = 0;
        }
    } else {
        g_rx_line[g_rx_pos++] = (char)ch;        // 累积字符
    }
}
```

### 🔍 调试检查点 (建议添加)
```c
// 在 process_line() 调用前添加:
osal_printk("[uart] line(%d): \"%s\"\r\n", g_rx_pos, g_rx_line);
```

### 启动时发送的 Grbl 兼容信息
```c
// task_uart_rx_entry() 启动后 500ms 发送:
"WS63 Laser Marker V1.0\r\n"
"Grbl 1.1f ['$' for help]\r\n"
// LaserGRBL 收到这行后识别设备
```

### ⚠️ 注意事项
- `g_rx_line` 最大 128 字节，LaserGRBL 发送的 G-Code 通常不超过 80 字节
- CRLF 处理: `\r` 和 `\n` 都作为行结束符，连续的 `\r\n` 中间不会产生空行（因为 `g_rx_pos > 0` 检查）

---

## 阶段③ 协议路由 — 命令分流

### 涉及文件
- [uart_handler.c](file:///root/fbb_ws63/src/ws63_test/transmitter/uart_handler.c#L37-L83) → `process_line()`

### 路由表
```
输入: char *line         示例
  ├─ line[0] == '?'  →  "?"                → grbl_format_status() → UART 回复
  ├─ line[0] == '$'  →  "$I" / "$G"        → grbl_process_dollar() → UART 回复
  └─ 其他             →  "G1 X10 Y20 F500" → gcode_process_line() → SLE 发送
```

### `?` 状态查询处理
```c
// 实际代码
bool is_idle = gcode_processor_is_idle() || !sle_laser_client_is_connected();
grbl_format_status(buf, sizeof(buf), 0, 0, 0, 0, is_idle);
uart_send_str(buf);

// 输出示例
"<Idle|MPos:0.000,0.000,0.000|FS:0,0>\r\n"
"<Run|MPos:0.000,0.000,0.000|FS:0,0>\r\n"
```

### `$` 命令处理
```c
"$I"  →  "[VER:1.1f.WS63:]\r\n[OPT:V,15,128]\r\nok\r\n"
"$G"  →  "[GC:G0 G54 G17 G21 G90 G94 M5 T0 F10000 S0]\r\nok\r\n"
"$X"  →  "ok\r\n"  (未知命令也回复 ok，防止 LaserGRBL 卡死)
```

### 🔍 调试检查点 (建议添加)
```c
// 在 process_line() 开头添加:
osal_printk("[proc] cmd: \"%s\" len=%d\r\n", line, len);
```

---

## 阶段④ G-Code 解析 — 文本到结构体

### 涉及文件
- [gcode_parser.c](file:///root/fbb_ws63/src/ws63_test/transmitter/gcode_parser.c) → 全部函数
- [gcode_parser.h](file:///root/fbb_ws63/src/ws63_test/transmitter/gcode_parser.h#L16-L19) → `gcode_line_t`

### 数据变换
```
输入: "g1 x10.5 y20.3 f500 s800"     (原始文本，可能小写)
      ↓ gcode_add_char() 逐字符转大写
内部: "G1 X10.5 Y20.3 F500 S800"     (gcode_line_t.line)
      ↓ gcode_parse() 去注释/trim
      ↓ gcode_has_word('G') → true
      ↓ gcode_get_value('G') → 1.0
      ↓ gcode_get_value('X') → 10.5
      ↓ gcode_get_value('Y') → 20.3
      ↓ gcode_get_value('F') → 500.0
      ↓ gcode_get_value('S') → 800.0
输出: 各参数提取为 double
```

### 解析器内部结构
```c
typedef struct {
    char line[128];   // 存储转大写后的文本
    int len;          // 有效长度
} gcode_line_t;
```

### 查找算法
```c
// gcode_has_word('X') 逻辑:
for (i=0; i<len; i++) {
    if (line[i]=='X' && (i==0 || !isalpha(line[i-1])))
        return true;   // 确保 X 不是某个单词的一部分
}
```

### 🔍 调试检查点 (建议添加)
```c
// 在 gcode_processor.c 的 gcode_process_line() 解析后:
osal_printk("[gcode] parsed: G=%d X=%.2f Y=%.2f F=%.1f S=%.1f\r\n",
    gcode_has_word(&gc,'G') ? (int)gcode_get_value(&gc,'G') : -1,
    gcode_has_word(&gc,'X') ? gcode_get_value(&gc,'X') : 0,
    gcode_has_word(&gc,'Y') ? gcode_get_value(&gc,'Y') : 0,
    gcode_has_word(&gc,'F') ? gcode_get_value(&gc,'F') : 0,
    gcode_has_word(&gc,'S') ? gcode_get_value(&gc,'S') : 0);
```

---

## 阶段⑤ 命令打包 — G-Code 结构体到 motion_cmd_t

### 涉及文件
- [gcode_processor.c](file:///root/fbb_ws63/src/ws63_test/transmitter/gcode_processor.c#L48-L159) → `gcode_process_line()`
- [protocol.h](file:///root/fbb_ws63/src/ws63_test/common/protocol.h#L29-L38) → `motion_cmd_t`

### 处理顺序 (严格按此执行)

```
一行 G-Code 最多产生 4 个 motion_cmd_t (例如同时含 S + M3 + G1 → 3 个命令)

顺序: ① 提取 F → ② 提取 S → ③ 处理 M → ④ 处理 G
```

#### 步骤① 提取 F 速率
```c
if (gcode_has_word(&gc, 'F')) {
    g_feed_rate = gcode_get_value(&gc, 'F');  // 保存到全局状态
}
// 不产生命令包，仅更新内部状态
```

#### 步骤② 提取 S 功率
```c
if (gcode_has_word(&gc, 'S')) {
    g_laser_power = clamp(s, 0, 1000);
    if (g_laser_enabled) {
        // 激光已开 → 立即发一个 CMD_LASER_ON 更新功率
        cmds[count++] = { cmd=0x03, laser_pwr=s, ... };
    }
}
```

#### 步骤③ 处理 M 命令
```c
M3 或 M4 → cmds[count++] = { cmd=CMD_LASER_ON(0x03),  laser_pwr=当前功率 }
M5      → cmds[count++] = { cmd=CMD_LASER_OFF(0x04) }
```

#### 步骤④ 处理 G 命令
```c
G90 → g_absolute_mode = true   (不产生命令包)
G91 → g_absolute_mode = false  (不产生命令包)
G92 → cmds[count++] = { cmd=CMD_SET_ORIGIN(0x05) }
G0  → cmds[count++] = { cmd=CMD_G0_MOVE(0x01), target_x, target_y, feed_rate=100000 }
G1  → cmds[count++] = { cmd=CMD_G1_MOVE(0x02), target_x, target_y, feed_rate=g_feed_rate }
```

### motion_cmd_t 数据包格式 (20 bytes, packed)

```
偏移  字段         类型      大小   示例值           含义
────  ────────     ──────    ────   ──────           ────
0x00  cmd          uint8     1B     0x02             CMD_G1_MOVE
0x01  flags        uint8     1B     0x03             激光开+绝对模式
0x02  seq          uint16    2B     0x0042           序列号 66
0x04  target_x     float     4B     0x41280000       10.5 mm
0x08  target_y     float     4B     0x41A26666       20.3 mm
0x0C  feed_rate    float     4B     0x43FA0000       500.0 mm/min
0x10  laser_pwr    uint16    2B     0x0320           800
0x12  crc16        uint16    2B     0xABCD           CRC16 校验
────  ────────     ──────    ────
                   总计      20B
```

### flags 位域定义
```
bit 0: FLAG_LASER_ON  (0x01)  — 激光当前是否开启
bit 1: FLAG_ABS_MODE  (0x02)  — 绝对坐标模式
bit 2-7: 保留
```

### CRC16 覆盖范围
```c
// crc16.h 中定义:
// 计算 cmd[0..17] 共 18 字节的 CRC，存入 cmd[18..19]
void motion_cmd_set_crc(motion_cmd_t *cmd);
bool motion_cmd_check_crc(const motion_cmd_t *cmd);
```

### 🔍 调试检查点 (建议添加)
```c
// 在 gcode_process_line() 返回前:
for (int i = 0; i < count; i++) {
    osal_printk("[cmd] #%d: cmd=0x%02x seq=%u X=%.2f Y=%.2f F=%.1f S=%u crc=0x%04x\r\n",
        i, cmds[i].cmd, cmds[i].seq,
        cmds[i].target_x, cmds[i].target_y,
        cmds[i].feed_rate, cmds[i].laser_pwr, cmds[i].crc16);
}
```

---

## 阶段⑥ SLE 无线发射 — 命令包到射频

### 涉及文件
- [uart_handler.c](file:///root/fbb_ws63/src/ws63_test/transmitter/uart_handler.c#L59-L83) → 流控+发送循环
- [sle_client.c](file:///root/fbb_ws63/src/ws63_test/transmitter/sle_client.c#L249-L262) → `sle_laser_client_send_cmd()`

### 发送前的流控
```c
// 等待接收板队列有空间
while (sle_laser_client_get_queue_free() < FLOW_CTRL_PAUSE_THRESHOLD(4)) {
    osal_msleep(5);     // 每 5ms 检查一次
    if (retry++ > 200)  // 超过 1s 超时退出
        break;
}
```

### SLE 发送调用链
```c
sle_laser_client_send_cmd(&cmd)
    → ssapc_write_req(client_id=0, conn_id, &param)
        param.handle = service.start_hdl + 1    // 命令 property handle
        param.type   = SSAP_PROPERTY_TYPE_VALUE
        param.data   = (uint8_t*)&cmd            // 20 bytes raw
        param.data_len = sizeof(motion_cmd_t)    // 20
    → SLE 协议栈自动分包、加密、射频发射
    → 接收板 ssaps_write_request_cbk() 收到
```

### SLE 连接建立流程
```
enable_sle()
  → sle_enable_cbk() 
    → sle_set_seek_param() + sle_start_seek()    // 开始扫描
      → sle_sample_seek_result_cbk()
        → 搜索广播数据中的 "LaserRX"
          → sle_stop_seek() + sle_connect_remote_device()
            → sle_connect_state_changed_cbk(CONNECTED)
              → ssapc_find_structure()            // 发现服务
                → sle_find_structure_cmp_cbk()
                  → ssapc_exchange_info_req(MTU=512)
                    → 连接就绪，可以发送命令 ✓
```

### 接收板反馈 (Notification)
```c
// 接收板每收到一个命令都回复 status_pkt_t (8 bytes):
typedef struct __attribute__((packed)) {
    uint8_t  status;      // 0x01 = RUNNING
    uint8_t  error_code;  // 0
    uint16_t ack_seq;     // 已确认的 seq
    uint8_t  queue_free;  // 剩余队列空间 (0-32)
    uint8_t  reserved;
    uint16_t crc16;
} status_pkt_t;

// sle_notification_cbk() 解析后更新:
g_last_ack_seq = pkt.ack_seq;    // 用于确认
g_queue_free = pkt.queue_free;   // 用于流控
```

### 🔍 调试检查点
```c
// sle_client.c 已有的调试打印:
"[laser tx] sle enable: 0x%x"       // SLE 协议栈启动
"[laser tx] scanning..."             // 开始扫描
"[laser tx] found LaserRX!"         // 找到接收板
"[laser tx] connected! conn_id=%u"   // 连接成功
"[laser tx] service found: ..."      // 服务发现
"[laser tx] MTU: %d"                // MTU 协商

// 建议在 send_cmd 中添加:
osal_printk("[sle] send seq=%u cmd=0x%02x ret=0x%x\r\n",
    cmd->seq, cmd->cmd, ret);
```

---

## 完整数据流示例

### 示例: LaserGRBL 发送 `G1 X10.5 Y20.3 F500 S800`

```
━━━ 阶段①  PC → UART ━━━
串口数据 (hex): 47 31 20 58 31 30 2E 35 20 59 32 30 2E 33 20 46 35 30 30 20 53 38 30 30 0A
                G  1     X  1  0  .  5     Y  2  0  .  3     F  5  0  0     S  8  0  0  \n

━━━ 阶段②  字节→行 ━━━
g_rx_line = "G1 X10.5 Y20.3 F500 S800"    (去掉了 \n)
g_rx_pos  = 24

━━━ 阶段③  路由 ━━━
line[0] = 'G' → 不是 '?' 也不是 '$' → gcode_process_line()

━━━ 阶段④  解析 ━━━
gcode_line_t.line = "G1 X10.5 Y20.3 F500 S800"   (已全大写)
提取: G=1, X=10.5, Y=20.3, F=500, S=800

━━━ 阶段⑤  打包 ━━━
步骤① F=500 → g_feed_rate = 500.0
步骤② S=800 → g_laser_power = 800, g_laser_enabled=true → 生成 CMD_LASER_ON
步骤③ 无 M 命令
步骤④ G=1 → 生成 CMD_G1_MOVE

产生 2 个命令包:
  cmds[0] = { cmd=0x03, flags=0x03, seq=N,   laser_pwr=800, crc=... }   // LASER_ON
  cmds[1] = { cmd=0x02, flags=0x03, seq=N+1, X=10.5, Y=20.3, F=500, S=800, crc=... }  // G1

g_line_counter → +1
g_last_activity_time → 当前 systick

━━━ 阶段⑥  SLE 发射 ━━━
检查流控: queue_free >= 4 → 可发送
ssapc_write_req() × 2 (依次发送 2 个 20 字节的包)
→ 射频发送 → 接收板收到

━━━ UART 回复 ━━━
uart_send_str("ok\r\n")  → PC 收到，继续发下一行
```

---

## 调试步骤 (从底层到上层)

### Step 1: 验证 UART 物理层
```
方法: 串口终端手动发送
  发送: $I\n
  期望: [VER:1.1f.WS63:]\r\n[OPT:V,15,128]\r\nok\r\n
  看 printk: "[uart] init OK, bus=1, TX=GPIO15, RX=GPIO16, baud=115200"
```

### Step 2: 验证 G-Code 解析
```
方法: 串口终端手动发送
  发送: G0 X100 Y100\n
  期望: ok\r\n
  看 printk: "[cmd] #0: cmd=0x01 seq=0 X=100.00 Y=100.00 ..."
```

### Step 3: 验证 SLE 连接 (需要接收板同时上电)
```
方法: 观察 printk 日志
  期望看到:
    [laser tx] sle enable: 0x0
    [laser tx] scanning...
    [laser tx] found LaserRX!
    [laser tx] connected! conn_id=0
    [laser tx] service found: start=0x... end=0x...
    [laser tx] MTU: 512
```

### Step 4: 验证 SLE 数据发送
```
方法: 两板上电，串口发送 G-Code
  看发射板 printk: "[sle] send seq=0 cmd=0x01 ret=0x0"   (ret=0 表示成功)
  看接收板 printk: "[laser rx] 应有对应的收到日志"
```

### Step 5: 验证 LaserGRBL 完整流程
```
方法: PC 打开 LaserGRBL，选择正确 COM 口
  期望: LaserGRBL 识别到 "Grbl 1.1f"
  发送: ? 查询
  期望: 状态栏显示 Idle
  开始打标 → 状态变为 Run → 完成后变回 Idle
```
