/**
 * @file sle_client.h
 * @brief 发射板 SLE Client — 连接接收板并发送运动命令
 */
#ifndef SLE_CLIENT_H
#define SLE_CLIENT_H

#include <stdint.h>
#include <stdbool.h>
#include "errcode.h"
#include "protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

errcode_t sle_laser_client_init(void);
errcode_t sle_laser_client_send_cmd(const motion_cmd_t *cmd);
bool sle_laser_client_is_connected(void);
uint8_t sle_laser_client_get_queue_free(void);
uint16_t sle_laser_client_get_last_ack_seq(void);

#ifdef __cplusplus
}
#endif

#endif /* SLE_CLIENT_H */
