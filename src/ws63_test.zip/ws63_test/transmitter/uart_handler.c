/**
 * @file uart_handler.c
 * @brief UART 处理器实现
 *        接收上位机 (LaserGRBL) 发送的 G-Code
 *        解析后通过 SLE 发送给接收板
 *        实现 Grbl 协议兼容 (ok 回复, ? 状态查询)
 */
#include "uart_handler.h"
#include "config.h"
#include "protocol.h"
#include "gcode_parser.h"
#include "gcode_processor.h"
#include "sle_client.h"
#include "soc_osal.h"
#include "uart.h"
#include "pinctrl.h"
#include <string.h>
#include <stdio.h>

/* UART 接收缓冲 */
#define RX_LINE_MAX 128
static char g_rx_line[RX_LINE_MAX];
static int g_rx_pos = 0;

/* UART 端口 — 由 config.h 定义 */

/* ================= UART 发送 ================= */
static void uart_send_str(const char *str)
{
    uint32_t len = (uint32_t)strlen(str);
    if (len > 0) {
        uapi_uart_write(LASER_UART_BUS, (const uint8_t *)str, len, 0);
    }
}

/* ================= 处理一行 G-Code ================= */
static void process_line(const char *line, int len)
{
    if (len == 0)
        return;

    /* '?' 实时命令 — 状态查询 */
    if (line[0] == '?') {
        char buf[80];
        /* 使用真实活动状态判定 Idle/Run (等效 Arduino lastActivityTime 逻辑) */
        bool is_idle = gcode_processor_is_idle() || !sle_laser_client_is_connected();
        grbl_format_status(buf, sizeof(buf), 0, 0, 0, 0, is_idle);
        uart_send_str(buf);
        return;
    }

    /* '$' Grbl 命令 */
    char response[128];
    if (grbl_process_dollar(line, response, sizeof(response))) {
        uart_send_str(response);
        return;
    }

    /* G-Code 处理 */
    motion_cmd_t cmds[4];
    int cmd_count = 0;

    if (gcode_process_line(line, len, cmds, &cmd_count)) {
        for (int i = 0; i < cmd_count; i++) {
            /* 流控: 等待接收板队列有空间 */
            int retry = 0;
            while (sle_laser_client_is_connected() && sle_laser_client_get_queue_free() < FLOW_CTRL_PAUSE_THRESHOLD) {
                osal_msleep(5);
                retry++;
                if (retry > 200)
                    break; /* 1s 超时 */
            }

            /* 发送命令 */
            if (sle_laser_client_is_connected()) {
                sle_laser_client_send_cmd(&cmds[i]);
            }
        }
    }

    /* 回复 "ok" — Grbl 协议要求每条命令都回复 */
    uart_send_str("ok\r\n");
}

/* ================= UART 接收任务 ================= */
int task_uart_rx_entry(void *arg)
{
    (void)arg;

    osal_printk("[uart] task started\r\n");

    /* 发送 Grbl 启动信息 */
    osal_msleep(500);
    uart_send_str("\r\nWS63 Laser Marker V1.0\r\n");
    uart_send_str("Grbl 1.1f ['$' for help]\r\n");

    uint8_t ch;
    while (1) {
        /* 读取一个字节 */
        int32_t ret = uapi_uart_read(LASER_UART_BUS, &ch, 1, 0);
        if (ret <= 0) {
            osal_msleep(1);
            continue;
        }

        /* 行结束符 */
        if (ch == '\n' || ch == '\r') {
            if (g_rx_pos > 0) {
                g_rx_line[g_rx_pos] = '\0';
                process_line(g_rx_line, g_rx_pos);
                g_rx_pos = 0;
            }
        } else {
            if (g_rx_pos < RX_LINE_MAX - 1) {
                g_rx_line[g_rx_pos++] = (char)ch;
            }
        }
    }

    return 0;
}

errcode_t uart_handler_init(void)
{
    /* 1. 配置 UART 引脚复用 */
#if defined(CONFIG_PINCTRL_SUPPORT_IE)
    uapi_pin_set_ie(LASER_UART_RX_PIN, PIN_IE_1);
#endif
    uapi_pin_set_mode(LASER_UART_TX_PIN, LASER_UART_PIN_MODE); /* GPIO15 → UART1_TXD */
    uapi_pin_set_mode(LASER_UART_RX_PIN, LASER_UART_PIN_MODE); /* GPIO16 → UART1_RXD */

    /* 2. UART 初始化 */
    uart_attr_t attr = {0};
    attr.baud_rate = UART_BAUD_RATE;
    attr.data_bits = UART_DATA_BIT_8;
    attr.stop_bits = UART_STOP_BIT_1;
    attr.parity = UART_PARITY_NONE;

    uart_pin_config_t pin_cfg = {0};
    pin_cfg.tx_pin = LASER_UART_TX_PIN; /* GPIO15 — Pin 9  */
    pin_cfg.rx_pin = LASER_UART_RX_PIN; /* GPIO16 — Pin 10 */
    pin_cfg.cts_pin = PIN_NONE;
    pin_cfg.rts_pin = PIN_NONE;

    errcode_t ret = uapi_uart_init(LASER_UART_BUS, &pin_cfg, &attr, NULL, NULL);
    if (ret != ERRCODE_SUCC) {
        osal_printk("[uart] init failed: 0x%x\r\n", ret);
        return ret;
    }

    osal_printk("[uart] init OK, bus=%d, TX=GPIO%d, RX=GPIO%d, baud=%d\r\n", LASER_UART_BUS, LASER_UART_TX_PIN,
                LASER_UART_RX_PIN, UART_BAUD_RATE);
    return ERRCODE_SUCC;
}
