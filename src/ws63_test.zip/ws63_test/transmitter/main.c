/**
 * @file main.c
 * @brief 发射板主入口 — 创建 UART 和 SLE 任务
 */
#include "app_init.h"
#include "soc_osal.h"
#include "common_def.h"
#include "config.h"

#include "gcode_processor.h"
#include "uart_handler.h"
#include "sle_client.h"

/* SLE 初始化任务 */
static int sle_init_task(void *arg)
{
    (void)arg;
    osal_msleep(500);
    sle_laser_client_init();
    return 0;
}

static void transmitter_entry(void)
{
    osal_printk("========================================\r\n");
    osal_printk("  WS63 Laser Marker - Transmitter Board\r\n");
    osal_printk("========================================\r\n");

    /* 1. 初始化 */
    gcode_processor_init();
    uart_handler_init();

    osal_printk("[transmitter] init OK\r\n");

    osal_task *task = NULL;

    osal_kthread_lock();

    /* 2. 创建 UART 接收任务 */
    task = osal_kthread_create(task_uart_rx_entry, NULL, "uart_rx", TASK_STACK_SIZE_DEFAULT);
    if (task != NULL) {
        osal_kthread_set_priority(task, TASK_PRIO_UART);
    }

    /* 3. 创建 SLE 初始化任务 */
    task = osal_kthread_create(sle_init_task, NULL, "sle_init", TASK_STACK_SIZE_SLE);
    if (task != NULL) {
        osal_kthread_set_priority(task, TASK_PRIO_SLE);
    }

    osal_kthread_unlock();

    osal_printk("[transmitter] all tasks created\r\n");
}

/* 系统启动入口 */
app_run(transmitter_entry);
