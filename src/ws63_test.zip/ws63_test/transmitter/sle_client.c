/**
 * @file sle_client.c
 * @brief 发射板 SLE Client 实现
 *        基于 sle_speed_client 示例改造
 *        扫描连接接收板 "LaserRX"，发送 motion_cmd_t，接收 status_pkt_t
 */
#include "sle_client.h"
#include "config.h"
#include "crc16.h"

#include "securec.h"
#include "soc_osal.h"
#include "common_def.h"
#include "sle_common.h"
#include "sle_errcode.h"
#include "sle_ssap_client.h"
#include "sle_connection_manager.h"
#include "sle_device_discovery.h"

/* ================= 状态变量 ================= */
static uint16_t g_conn_id = 0;
static bool g_connected = false;
static uint8_t g_queue_free = CMD_QUEUE_SIZE;
static uint16_t g_last_ack_seq = 0;
static sle_addr_t g_remote_addr = {0};

static ssapc_find_service_result_t g_find_service_result = {0};

/* ================= 扫描回调 ================= */
static void sle_sample_sle_enable_cbk(errcode_t status)
{
    osal_printk("[laser tx] sle enable: 0x%x\r\n", status);
    if (status == ERRCODE_SLE_SUCCESS) {
        /* 开始扫描 */
        sle_seek_param_t param = {0};
        param.own_addr_type = 0;
        param.filter_duplicates = 0;
        param.seek_filter_policy = 0;
        param.seek_phys = 1;
        param.seek_type[0] = 0;
        param.seek_interval[0] = 0x64;
        param.seek_window[0] = 0x64;
        sle_set_seek_param(&param);
        sle_start_seek();
        osal_printk("[laser tx] scanning...\r\n");
    }
}

static void sle_sample_seek_result_cbk(sle_seek_result_info_t *seek_result)
{
    if (seek_result == NULL || seek_result->data == NULL)
        return;

    /* 在广播数据中查找 "LaserRX" 设备名 */
    uint8_t *data = seek_result->data;
    uint16_t len = seek_result->data_length;

    for (uint16_t i = 0; i < len;) {
        if (i + 1 >= len)
            break;
        uint8_t ad_type = data[i];
        uint8_t ad_len = data[i + 1];

        if (ad_type == SLE_ADV_DATA_TYPE_COMPLETE_LOCAL_NAME && ad_len >= 7) {
            if (memcmp(&data[i + 2], "LaserRX", 7) == 0) {
                osal_printk("[laser tx] found LaserRX!\r\n");
                memcpy_s(&g_remote_addr, sizeof(sle_addr_t), &seek_result->addr, sizeof(sle_addr_t));
                sle_stop_seek();
                /* 发起连接 */
                sle_connection_param_update_t param = {0};
                param.conn_id = 0;
                param.interval_min = 0x14;
                param.interval_max = 0x14;
                param.max_latency = 0;
                param.supervision_timeout = 0x1F4;
                sle_connect_remote_device(&g_remote_addr);
                return;
            }
        }
        i += ad_len + 2;
    }
}

static void sle_sample_seek_enable_cbk(errcode_t status)
{
    osal_printk("[laser tx] seek enable: 0x%x\r\n", status);
}

static void sle_sample_seek_disable_cbk(errcode_t status)
{
    osal_printk("[laser tx] seek disable: 0x%x\r\n", status);
}

/* ================= 连接回调 ================= */
static void sle_connect_state_changed_cbk(uint16_t conn_id,
                                          const sle_addr_t *addr,
                                          sle_acb_state_t conn_state,
                                          sle_pair_state_t pair_state,
                                          sle_disc_reason_t disc_reason)
{
    unused(addr);
    unused(pair_state);
    unused(disc_reason);

    if (conn_state == SLE_ACB_STATE_CONNECTED) {
        g_conn_id = conn_id;
        g_connected = true;
        osal_printk("[laser tx] connected! conn_id=%u\r\n", conn_id);

        /* 发现服务 */
        ssapc_find_structure_param_t find_param = {0};
        find_param.type = SSAP_FIND_TYPE_PRIMARY_SERVICE;
        find_param.start_hdl = 1;
        find_param.end_hdl = 0xFFFF;
        ssapc_find_structure(0, conn_id, &find_param);
    } else if (conn_state == SLE_ACB_STATE_DISCONNECTED) {
        g_connected = false;
        osal_printk("[laser tx] disconnected, restarting scan\r\n");
        osal_msleep(1000);
        sle_start_seek();
    }
}

static void sle_pair_complete_cbk(uint16_t conn_id, const sle_addr_t *addr, errcode_t status)
{
    unused(conn_id);
    unused(addr);
    osal_printk("[laser tx] pair complete: 0x%x\r\n", status);
}

static void sle_auth_complete_cbk(uint16_t conn_id,
                                  const sle_addr_t *addr,
                                  errcode_t status,
                                  const sle_auth_info_evt_t *evt)
{
    unused(conn_id);
    unused(addr);
    unused(evt);
    osal_printk("[laser tx] auth complete: 0x%x\r\n", status);
}

/* ================= SSAP Client 回调 ================= */
static void sle_exchange_info_cbk(uint8_t client_id, uint16_t conn_id, ssap_exchange_info_t *param, errcode_t status)
{
    unused(client_id);
    unused(conn_id);
    unused(status);
    osal_printk("[laser tx] MTU: %d\r\n", param->mtu_size);
}

static void sle_find_structure_cbk(uint8_t client_id,
                                   uint16_t conn_id,
                                   ssapc_find_service_result_t *service,
                                   errcode_t status)
{
    unused(client_id);
    unused(conn_id);
    unused(status);

    if (service != NULL) {
        memcpy_s(&g_find_service_result, sizeof(ssapc_find_service_result_t), service,
                 sizeof(ssapc_find_service_result_t));
        osal_printk("[laser tx] service found: start=0x%x end=0x%x\r\n", service->start_hdl, service->end_hdl);
    }
}

static void sle_find_structure_cmp_cbk(uint8_t client_id,
                                       uint16_t conn_id,
                                       ssapc_find_structure_result_t *result,
                                       errcode_t status)
{
    unused(client_id);
    unused(conn_id);
    unused(result);
    unused(status);
    osal_printk("[laser tx] find structure complete\r\n");

    /* 交换 MTU */
    ssap_exchange_info_t info = {0};
    info.mtu_size = 512;
    info.version = 1;
    ssapc_exchange_info_req(0, g_conn_id, &info);
}

/**
 * @brief Notification 回调 — 接收接收板发来的 status_pkt_t
 */
static void sle_notification_cbk(uint8_t client_id, uint16_t conn_id, ssapc_handle_value_t *data, errcode_t status)
{
    unused(client_id);
    unused(conn_id);
    unused(status);

    if (data == NULL || data->data == NULL || data->data_len < sizeof(status_pkt_t)) {
        return;
    }

    status_pkt_t pkt;
    memcpy(&pkt, data->data, sizeof(status_pkt_t));

    if (status_pkt_check_crc(&pkt)) {
        g_last_ack_seq = pkt.ack_seq;
        g_queue_free = pkt.queue_free;
    }
}

static void sle_indication_cbk(uint8_t client_id, uint16_t conn_id, ssapc_handle_value_t *data, errcode_t status)
{
    unused(client_id);
    unused(conn_id);
    unused(data);
    unused(status);
}

/* ================= 初始化 ================= */
errcode_t sle_laser_client_init(void)
{
    /* 注册扫描/广播回调 */
    sle_announce_seek_callbacks_t seek_cbk = {0};
    seek_cbk.sle_enable_cb = sle_sample_sle_enable_cbk;
    seek_cbk.seek_enable_cb = sle_sample_seek_enable_cbk;
    seek_cbk.seek_disable_cb = sle_sample_seek_disable_cbk;
    seek_cbk.seek_result_cb = sle_sample_seek_result_cbk;
    sle_announce_seek_register_callbacks(&seek_cbk);

    /* 注册连接回调 */
    sle_connection_callbacks_t conn_cbk = {0};
    conn_cbk.connect_state_changed_cb = sle_connect_state_changed_cbk;
    conn_cbk.pair_complete_cb = sle_pair_complete_cbk;
    conn_cbk.auth_complete_cb = sle_auth_complete_cbk;
    sle_connection_register_callbacks(&conn_cbk);

    /* 注册 SSAP Client 回调 */
    ssapc_callbacks_t ssapc_cbk = {0};
    ssapc_cbk.exchange_info_cb = sle_exchange_info_cbk;
    ssapc_cbk.find_structure_cb = sle_find_structure_cbk;
    ssapc_cbk.find_structure_cmp_cb = sle_find_structure_cmp_cbk;
    ssapc_cbk.notification_cb = sle_notification_cbk;
    ssapc_cbk.indication_cb = sle_indication_cbk;
    ssapc_register_callbacks(&ssapc_cbk);

    /* 使能 SLE */
    enable_sle();
    osal_printk("[laser tx] SLE enable called\r\n");

    return ERRCODE_SLE_SUCCESS;
}

errcode_t sle_laser_client_send_cmd(const motion_cmd_t *cmd)
{
    if (!g_connected) {
        return ERRCODE_SLE_FAIL;
    }

    ssapc_write_param_t param = {0};
    param.handle = g_find_service_result.start_hdl + 1; /* 命令 property handle */
    param.type = SSAP_PROPERTY_TYPE_VALUE;
    param.data_len = sizeof(motion_cmd_t);
    param.data = (uint8_t *)cmd;

    return ssapc_write_req(0, g_conn_id, &param);
}

bool sle_laser_client_is_connected(void)
{
    return g_connected;
}

uint8_t sle_laser_client_get_queue_free(void)
{
    return g_queue_free;
}

uint16_t sle_laser_client_get_last_ack_seq(void)
{
    return g_last_ack_seq;
}
